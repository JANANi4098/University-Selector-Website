# UNIVERSITY-SELECTOR
easy to find best university across India
